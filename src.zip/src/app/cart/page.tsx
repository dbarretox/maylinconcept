'use client'

import { useCart } from '@/context/CartContext'
import { Button } from '@/components/ui/button'
import { Trash2, Plus, Minus } from 'lucide-react'
import Link from 'next/link'

export default function CartPage() {
    const { items, updateQuantity, removeFromCart, getTotal } = useCart()

    if (items.length === 0) {
        return (
            <div className="container mx-auto px-4 py-16 text-center">
                <h1 className="text-3xl font-bold mb-4">Tu carrito está vacío</h1>
                <p className="text-muted-foreground mb-8">
                    Agregar algunos productos para comenzar
                </p>
                <Link href="/products">
                    <Button size="lg">Ver Productos</Button>
                </Link>
            </div>
        )
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold mb-8">Carrito de Compras</h1>
            <div className="grid gap-4 lg:grid-cols-3">
                <div className="lg:col-span-2 space-y-4">
                    {items.map((item) => (
                        <div key={item.id} className="flex flex-col sm:flex-row gap-4 bg-card p-4 rounded-lg border">
                            {item.image && (
                                <img
                                    src={item.image}
                                    alt={item.name}
                                    className="w-full sm:w-24 h-48 sm:h-24 object-cover rounded"
                                />
                            )}

                            <div className="flex-1 space-y-2">
                                <h3 className="font-semibold">{item.name}</h3>
                                <p className="text-muted-foreground">${item.price}</p>
                            </div>

                            <div className="flex items-center jsitfy-between sm:justify-start gap-2">
                                <div className="flex items-center gap-2">
                                    <Button
                                        size="icon"
                                        variant="outline"
                                        onClick={() => updateQuantity(item.id, item.quantity - 1)}
                                    >
                                        <Minus className="h-4 w-4" />
                                    </Button>
                                    <span className="w-12 text-center">{item.quantity}</span>
                                    <Button
                                        size="icon"
                                        variant="outline"
                                        onClick={() => updateQuantity(item.id, item.quantity + 1)}
                                    >
                                        <Plus className="h-4 w-4" />
                                    </Button>
                                </div>
                                <Button
                                    size="icon"
                                    variant="ghost"
                                    className="text-destructive"
                                    onClick={() => removeFromCart(item.id)}
                                >
                                    <Trash2 className="h-4 w-4" />
                                </Button>
                            </div>

                        </div>
                    ))}
                </div>
                <div className="lg:col-span-1">
                    <div className="bg-card p-4 sm:p-6 rounded-lg border lg:sticky lg:top-20">
                        <h2 className="text-xl font-semibold mb-4">
                            Resumen del pedido
                        </h2>

                        <div className="space-y-2 mb-4">
                            <div className="flex justify-between text-sm sm:text-base">
                                <span>Subtotal</span>
                                <span>${getTotal()}</span>
                            </div>
                            <div className="flex justify-between font-semibold text-base sm:text-lg pt-2 border-t">
                                <span>Total</span>
                                <span>${getTotal()}</span>
                            </div>
                        </div>
                        <Link href="/checkout">
                            <Button className="w-full" size="lg">
                                Proceder al pago
                            </Button>
                        </Link>
                    </div>
                </div>
            </div>
        </div>
    )
}