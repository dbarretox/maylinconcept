import { getProducts } from '@/lib/graphql/queries'
import { ProductCard } from '@/components/ProductCard'
import { Product } from '@/types/product'
import Link from 'next/link'
import { Button } from '@/components/ui/button'


export default async function HomePage() {
  const data = await getProducts()

  const featuredProducts = data.products.nodes.slice(0, 4)

  return (
    <div className="container mx-auto px-4 py-8">
      <section className="text-center mb-12">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">
          Maylin Concept Store
        </h1>
        <p className="netxt-lg text-muted-foreground max-w-2xl mx-auto">
          Tienda customizable de swaters, tazas, stickers y más.
          Productos únicos diseñados con amor.
        </p>
      </section>
      <section className="mb-12">
        <h2 className="text-2xl font-semibold mb-6">
          Productos Destacados
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {featuredProducts.map((product: Product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>

        <div className="text-center">
          <Link href="/products">
            <Button size="lg" variant="outline">
                Ver todos los productos
            </Button>
          </Link>
        </div>
      </section>
    </div>
  )
}