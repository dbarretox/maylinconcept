'use client'

import { useSearchParams } from 'next/navigation'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { CheckCircle } from 'lucide-react'
import Link from 'next/link'
import { Button } from '@/components/ui/button'

export default function OrderSuccessPage() {
  const searchParams = useSearchParams()
  const orderId = searchParams.get('id')

  return (
    <div className="container mx-auto px-4 py-16">
      <div className="max-w-md mx-auto">
        <Card className="text-center">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <CheckCircle className="h-16 w-16 text-green-500" />
            </div>
            <CardTitle className="text-2xl">
              ¡Pedido Confirmado!
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-muted-foreground">
              Tu pedido ha sido recibido exitosamente.
            </p>
            
            {orderId && (
              <div className="bg-muted p-4 rounded-lg">
                <p className="text-sm font-medium">
                  Número de orden: #{orderId}
                </p>
              </div>
            )}
            
            <p className="text-sm">
              Revisaremos tu comprobante de pago y te contactaremos 
              pronto para confirmar el envío.
            </p>
            <div className="pt-4 space-y-2">
              <Link href="/products" className="block">
                <Button className="w-full" size="lg">
                  Seguir Comprando
                </Button>
              </Link>
              
              <Link href="/" className="block">
                <Button variant="outline" className="w-full">
                  Volver al Inicio
                </Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}