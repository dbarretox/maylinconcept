'use client'

import { useCart } from '@/context/CartContext'
import { useRouter } from 'next/navigation'
import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Button } from '@/components/ui/button'
import { Separator } from '@/components/ui/separator'
import { toast } from 'sonner'
import { graphqlClient, authenticatedRequest } from '@/lib/graphql/client'
import { CREATE_ORDER_MUTATION } from '@/lib/graphql/queries'
import { uploadToWordPress } from '@/lib/upload'

export default function CheckoutPage() {
    const { items, getTotal, clearCart } = useCart()
    const router = useRouter()

    useEffect(() => {
        if (items.length === 0) {
            router.push('/cart')
        }
    }, [items, router])

    const [formData, setFormData] = useState({
        customerName: '',
        customerEmail: '',
        customerPhone: ''
    })
    const [paymentFile, setPaymentFile] = useState<File | null>(null)
    const [isSubmitting, setIsSubmitting] = useState(false)

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const { name, value } = e.target
        setFormData(prev => ({
            ...prev,
            [name]: value
        }))
    }

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0]
        if (file) {
            setPaymentFile(file)
            toast.success('Comprobante cargado')
        }
    }

    // Tipo para la respuesta de la mutation
    interface CreateOrderResponse {
        createShopOrder: {
            shopOrder: {
                id: string
                databaseId: string
            }
        }
    }

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault()

        if (!paymentFile) {
            toast.error('Por favor sube el comprobante de pago')
            return
        }

        setIsSubmitting(true)

        try {
            // Primero subir el archivo
            const receiptUrl = await uploadToWordPress(paymentFile)

            // Preparar items como JSON
            const orderItemsData = items.map(item => ({
                id: item.id,
                name: item.name,
                price: item.price,
                quantity: item.quantity
            }))

            // Enviar orden a WordPress
            const response = await authenticatedRequest<CreateOrderResponse>(
                CREATE_ORDER_MUTATION,
                {
                    input: {
                        title: `Pedido - ${formData.customerName}`,
                        content: JSON.stringify({
                            customerName: formData.customerName,
                            customerEmail: formData.customerEmail,
                            customerPhone: formData.customerPhone,
                            orderItems: orderItemsData,
                            orderTotal: getTotal(),
                            paymentReceipt: receiptUrl,
                            orderStatus: 'pending'
                        }),
                        status: "PUBLISH"
                    }
                }
            )

            // Limpiar carrito y mostrar éxito
            clearCart()
            toast.success('¡Pedido enviado con éxito!')

            // Redirigir a página de confirmación
            router.push(`/order-success?id=${response.createShopOrder.shopOrder.databaseId}`)

        } catch (error) {
            console.error('Error al procesar pedido:', error)
            toast.error('Error al procesar el pedido. Intenta nuevamente.')
        } finally {
            setIsSubmitting(false)
        }
    }

    return (
        <div className="container mx-auto px-4 py-8">
            <h1 className="text-3xl font-bold mb-8">Finalizar Compra</h1>

            <div className="grid gap-8 lg:grid-cols-2">
                <Card className="p-6">
                    <CardHeader>
                        <CardTitle>Información del Cliente</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div>
                            <Label htmlFor="customerName">Nombre completo</Label>
                            <Input
                                id="customerName"
                                name="customerName"
                                value={formData.customerName}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="customerEmail">Correo electrónico</Label>
                            <Input
                                id="customerEmail"
                                name="customerEmail"
                                type="email"
                                value={formData.customerEmail}
                                onChange={handleInputChange}
                                required
                            />
                        </div>

                        <div>
                            <Label htmlFor="customerPhone">Teléfono</Label>
                            <Input
                                id="customerPhone"
                                name="customerPhone"
                                type="tel"
                                value={formData.customerPhone}
                                onChange={handleInputChange}
                                required
                            />
                        </div>
                        <div>
                            <Label htmlFor="paymentFile">Comprobante de pago</Label>
                            <Input
                                id="paymentFile"
                                type="file"
                                accept="image/*,.pdf"
                                onChange={handleFileChange}
                                required
                            />
                            <p className="text-sm text-muted-foreground mt-1">
                                Sube tu comprobante de transferencia (imagen o PDF)
                            </p>
                        </div>
                    </CardContent>
                </Card>

                <Card className="p-6">
                    <CardHeader>
                        <CardTitle>Resumen del Pedido</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="space-y-2">
                            {items.map((item) => (
                                <div key={item.id} className="flex justify-between text-sm">
                                    <span>{item.name} x{item.quantity}</span>
                                    <span>${(parseFloat(item.price) * item.quantity).toFixed(2)}</span>
                                </div>
                            ))}
                        </div>
                        <Separator />
                        <div className="flex justify-between font-bold">
                            <span>Total</span>
                            <span>${getTotal()}</span>
                        </div>

                        <Button
                            className="w-full"
                            size="lg"
                            disabled={isSubmitting}
                            onClick={handleSubmit}
                        >
                            {isSubmitting ? 'Procesando...' : 'Confirmar Pedido'}
                        </Button>
                    </CardContent>
                </Card>
            </div>
        </div>
    )
}