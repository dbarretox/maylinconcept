import type { Metadata } from "next";
import "./globals.css";
import { CartProvider } from '@/context/CartContext'
import { Toaster } from '@/components/ui/sonner'
import { Header } from '@/components/Header' 

export const metadata: Metadata = {
  title: "Maylin Concept Store",
  description: "Tienda Customizable de sweter, tasas, sticker y más",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="es">
      <body>
        <CartProvider>
          <Header />
          <main className="min-h-screen">
            {children}
          </main>
          <Toaster position="top-center" richColors closeButton />
        </CartProvider>
      </body>
    </html>
  )
}
