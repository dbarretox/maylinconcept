import { ProductCard } from "@/components/ProductCard"
import { Product } from '@/types/product'
import { graphqlClient } from '@/lib/graphql/client'
import { GET_ALL_PRODUCTS } from '@/lib/graphql/queries'

interface ProductsResponse {
    products: {
        nodes: Product[]
    }
}

export default async function TestProductsPage() {
    try {
        const data: ProductsResponse = await graphqlClient.request(GET_ALL_PRODUCTS)
        console.log('Productos:', data)

        return (
            <div className="container mx-auto p-8">
                <h1 className="text-3xl font-bold mb-8">Productos</h1>

                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
                    {data.products.nodes.map((product: Product) => (
                        <ProductCard key={product.id} product={product} />
                    ))}
                </div>
            </div>
        )
    } catch (error) {
        console.error('Error:', error)
    }
}