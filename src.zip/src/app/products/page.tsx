import { getProducts } from '@/lib/graphql/queries'
import { ProductCard } from '@/components/ProductCard'

export default async function ProductsPage() {
  const { products } = await getProducts()

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">
        Nuestros Productos
      </h1>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {products.nodes.map((product) => (
          <ProductCard 
            key={product.id} 
            product={product} 
          />
        ))}
      </div>
      
      {products.nodes.length === 0 && (
        <p className="text-center text-muted-foreground py-8">
          No hay productos disponibles en este momento.
        </p>
      )}
    </div>
  )
}