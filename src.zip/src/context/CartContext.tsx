'use client'

import { createContext, useContext, useState, ReactNode } from 'react'
import { CartItem } from '@/types/cart'

interface CartContextType {
    items: CartItem[]
    addToCart: (item: CartItem) => void
    removeFromCart: (id: string) => void
    updateQuantity: (id: string, quantity: number) => void
    clearCart: () => void
    getTotal: () => string
}

const CartContext = createContext<CartContextType | undefined>(undefined)

export function CartProvider({ children }: { children: ReactNode }) {
    const [items, setItems] = useState<CartItem[]>([])

    const addToCart = (newItem: CartItem) => {
        setItems(current => {
            const existingItem = current.find(item => item.id === newItem.id)

            if (existingItem) {
                return current.map(item =>
                    item.id === newItem.id
                        ? { ...item, quantity: item.quantity + newItem.quantity }
                        : item
                )
            }

            return [...current, newItem]
        })
    }

    const removeFromCart = (id: string) => {
        setItems(current => current.filter(item => item.id !== id))
    }

    const updateQuantity = (id: string, quantity: number) => {
        if (quantity <= 0) {
            removeFromCart(id)
            return
        }

        setItems(current =>
            current.map(item =>
                item.id === id ? { ...item, quantity } : item
            )
        )
    }

    const clearCart = () => {
        setItems([])
    }

    const getTotal = (): string => {
        const total = items.reduce((sum, item) => {
            const itemTotal = parseFloat(item.price) * item.quantity
            return sum + itemTotal
        }, 0)

        return total.toFixed(2)
    }

    return (
        <CartContext.Provider
            value={{
                items,
                addToCart,
                removeFromCart,
                updateQuantity,
                clearCart,
                getTotal
            }}
        >
            {children}
        </CartContext.Provider>
    )
}

export function useCart() {
    const context = useContext(CartContext)

    if (context === undefined) {
        throw new Error('useCart debe usarse dentro de CartProvider')
    }

    return context
}