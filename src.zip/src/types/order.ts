export interface OrderInput {
  customerName: string
  customerEmail: string
  customerPhone: string
  orderItems: string
  orderTotal: string
  paymentReceipt?: string
  orderStatus?: string
}