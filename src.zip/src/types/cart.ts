export interface CartItem {
    id: string
    name: string
    price: string
    quantity: number
    image?: string
}

export interface CartState {
    items: CartItem[]
    total: number
}