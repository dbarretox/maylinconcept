export interface Product {
    id: string
    title: string
    slug: string
    productFields: {
        price: string
        mainImage: {
            node: {
                sourceUrl: string
            }
        } | null
    }
}