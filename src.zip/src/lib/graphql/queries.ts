import { gql } from 'graphql-request'
import { graphqlClient } from './client'
import { Product } from '@/types/product'

interface ProductsResponse {
    products: {
        nodes: Product[]
    }
}

export const GET_ALL_PRODUCTS = gql`
    query GetAllProducts {
        products {
            nodes {
                id
                title
                slug
                productFields {
                    price
                    mainImage {
                        node {
                            sourceUrl
                        }
                    }
                }
            }
        }
    }
`
export async function getProducts(): Promise<ProductsResponse> {
  return await graphqlClient.request<ProductsResponse>(GET_ALL_PRODUCTS);
}

export const CREATE_ORDER_MUTATION = gql`
  mutation CreateOrder($input: CreateShopOrderInput!) {
    createShopOrder(input: $input) {
      shopOrder {
        id
        databaseId
      }
    }
  }
`