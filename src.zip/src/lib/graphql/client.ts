import { GraphQLClient } from 'graphql-request'

const endpoint = process.env.NEXT_PUBLIC_GRAPHQL_ENDPOINT || 'https://admin.maylinconcept.com/graphql'

// Función para obtener token JWT
async function getAuthToken() {
  const response = await fetch(`${process.env.NEXT_PUBLIC_WORDPRESS_URL}/wp-json/jwt-auth/v1/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: 'adminMC',
      password: 'MyStore!Admin2025'
    })
  })
  
  if (!response.ok) throw new Error('Failed to authenticate')
  const data = await response.json()
  return data.token
}

// Crear cliente con autenticación
export const graphqlClient = new GraphQLClient(endpoint)

// Función para requests autenticadas
export async function authenticatedRequest<T = any>(query: string, variables?: any): Promise<T> {
  const token = await getAuthToken()
  return graphqlClient.request(query, variables, {
    Authorization: `Bearer ${token}`
  })
}