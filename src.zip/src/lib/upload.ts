export async function uploadToWordPress(file: File): Promise<string> {
  // Primero obtener un token JWT para REST API
  const tokenResponse = await fetch(`${process.env.NEXT_PUBLIC_WORDPRESS_URL}/wp-json/jwt-auth/v1/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      username: 'adminMC',
      password: 'MyStore!Admin2025'
    })
  })

  if (!tokenResponse.ok) {
    throw new Error('Error al autenticar')
  }

  const { token } = await tokenResponse.json()
  
  // Ahora subir el archivo
  const formData = new FormData()
  formData.append('file', file)
  
  const response = await fetch(`${process.env.NEXT_PUBLIC_WORDPRESS_URL}/wp-json/wp/v2/media`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`
    },
    body: formData
  })

  if (!response.ok) {
    throw new Error('Error al subir archivo')
  }
  
  const data = await response.json()
  return data.source_url
}