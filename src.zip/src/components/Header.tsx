'use client'

import Link from 'next/link'
import { CartIcon } from './CartIcon'

export function Header() {
    return (
        <header className="border-b">
            <div className="container mx-auto px-4 h-16 flex items-center justify-between">
                <Link href="/" className="text-xl font-bold">
                    Maylin Concept
                </Link>

                <nav className="flex items-center gap-6">
                    <Link href="/products" className="hover:text-primary transition-colors">
                        Productos
                    </Link>
                    <Link href="/cart">
                        <CartIcon />
                    </Link>
                </nav>
            </div>
        </header>
    )
}