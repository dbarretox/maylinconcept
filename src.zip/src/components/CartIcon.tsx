'use Client'

import { ShoppingCart } from 'lucide-react'
import { useCart } from '@/context/CartContext'
import { Button } from './ui/button'

export function CartIcon() {
    const { items } = useCart()
    const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)

    return (
        <Button variant="ghost" size="icon" className="relative">
            <ShoppingCart className="h-5 w-5" />
            {totalItems > 0 && (
                <span className="absolute -tp-1 -right-1 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                    {totalItems}
                </span>
            )}
        </Button>
    )
}