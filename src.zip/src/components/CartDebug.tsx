'use client';

import { useCart } from '@/context/CartContext';

export function CartDebug() {
  const { items, getTotal } = useCart();

  const totalItems = items.reduce((sum, item) => sum + item.quantity, 0)
  
  return (
    <div className="fixed bottom-4 right-4 bg-black text-white p-4 rounded">
      <p>Items unicos: {items.length}</p>
      <p>Cantidad total: {totalItems}</p>
      <p>Total: ${getTotal()}</p>
    </div>
  );
}