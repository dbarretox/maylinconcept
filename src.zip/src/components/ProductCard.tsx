'use client'

import { Product } from '@/types/product'
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { useCart } from "@/context/CartContext"
import { toast } from 'sonner'

interface ProductCardProps {
    product: Product
}

export function ProductCard({ product }: ProductCardProps) {
    const { addToCart } = useCart()

    const handleAddToCart = () => {
        addToCart({
            id: product.id,
            name: product.title,
            price: product.productFields.price,
            quantity: 1,
            image: product.productFields.mainImage?.node.sourceUrl
        })

        toast.success('Producto agregado al carrito')
    }


    return (
        <Card className="overflow-hidden">
            <CardHeader className="p-0">
                <div className="aspect-square bg-gray-100">
                    {product.productFields.mainImage ? (
                        <img
                            src={product.productFields.mainImage.node.sourceUrl}
                            alt={product.title}
                            className="w-full h-full object-cover"
                        />
                    ) : (
                        <div className="w-full h-full flex items-center justify-center text-gray-400">
                            Sin imagen
                        </div>
                    )}
                </div>
            </CardHeader>
            <CardContent className="p-4">
                <CardTitle className="line-clamp-2">{product.title}</CardTitle>
                <p className="text-2xl font-bold mt-2">
                    ${product.productFields.price}
                </p>
            </CardContent>
            <CardFooter className="p-4 pt-0">
                <Button
                    className="w-full"
                    onClick={handleAddToCart}
                >
                    Agregar al carrito
                </Button>
            </CardFooter>
        </Card>
    )
}